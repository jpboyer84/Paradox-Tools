(() => {
  'use strict';

  const PLATFORM = 'paradox';

  // Anonymous usage telemetry (see telemetry.js). Safe no-op if unavailable.
  function track(event, fields) {
    try { if (typeof window.prbdTrack === 'function') window.prbdTrack(event, Object.assign({ platform: PLATFORM }, fields || {})); } catch (e) {}
  }
  let panelOpenTracked = false;

  // ══════════════════════════════════════════════════════
  // STATE
  // ══════════════════════════════════════════════════════

  let panel = null;
  let isOpen = false;
  let activeTab = 'resumes'; // 'resumes' or 'disposition'

  // Shared
  let candidates = [];
  let selectedIds = new Set();
  let isScanning = false;
  let isLoadingStages = false;
  let stagesLoaded = false;
  // Each filter option: { label, stageIds: [], statusIds: [] }
  let scanFilterOptions = [];
  let selectedFilterIndex = 0; // index into scanFilterOptions, 0 = first option
  let scanLimit = 0; // 0 = all candidates
  let scanOffset = 0; // pagination offset for limited scans
  let totalAvailable = 0; // total candidates available from API
  let isPrevious = false; // true = previous job opening candidates
  let scanKeyword = ''; // keyword passed to API at scan time
  let candidateTypeFilter = 'all'; // 'all' | 'internal' | 'external'
  let nameFilter = ''; // client-side name filter on scanned list
  let setupOpen = true; // scan setup card expanded/collapsed

  // Session cache: lead data per candidate, so re-scans (keyword searches,
  // pagination, filter changes) only check candidates not yet seen.
  // Keyed per job + opening type; cleared on change. Dispositioned
  // candidates are evicted so stage info never goes stale.
  const leadCache = new Map();
  let leadCacheKey = '';

  // Resume state
  let isDownloading = false;
  let downloadProgress = { done: 0, total: 0, errors: [] };
  let downloadMode = 'folder';
  let dlStatus = ''; // persistent download status line

  // Disposition state
  let isDisposing = false;
  let disposeProgress = { done: 0, total: 0, errors: [] };
  let journeyStages = [];
  let nextStepsData = null; // from check-journey-next-steps
  let selectedNextStepId = null; // the next_step button (e.g., "Disposition")
  let selectedStatusId = null; // the specific status within that next step

  // ══════════════════════════════════════════════════════
  // HELPERS
  // ══════════════════════════════════════════════════════

  function getCSRFToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    if (meta) return meta.getAttribute('content');
    const match = document.cookie.match(/csrftoken=([^;]+)/);
    return match ? match[1] : '';
  }

  function getSubdomain() { return window.location.hostname.split('.')[0]; }

  function apiHeaders() {
    return { 'accept': 'application/json, text/plain, */*', 'x-csrftoken': getCSRFToken(), 'x-requested-with': 'XMLHttpRequest' };
  }

  function getPageContext() {
    const p = new URL(window.location.href).searchParams;
    return { liveJobUuid: p.get('selected'), journeyId: p.get('journey') };
  }

  function candidateFilename(name, ext) {
    return name.replace(/[^a-zA-Z0-9 _-]/g, '').replace(/\s+/g, '_') + (ext || '.pdf');
  }

  // Reads the "Internal/External" attribute from the candidate list API data.
  // Only an explicit "internal" value marks a candidate internal; everyone
  // else (including candidates missing the attribute) counts as external.
  function extractCandidateType(c) {
    try {
      const sections = c.candidate_summary_data?.candidate_summary_sections || [];
      for (const sec of sections) {
        for (const f of (sec.attribute_fields || [])) {
          if ((f.field_name || '').toLowerCase() === 'internal/external') {
            const v = String(f.key_value ?? f.value ?? '').toLowerCase().trim();
            if (v === 'internal') return 'internal';
          }
        }
      }
      // Fallback: profile card fields
      for (const f of (c.candidate_summary_data?.profile_card_fields || [])) {
        if (String(f.value ?? '').toLowerCase().trim() === 'internal') return 'internal';
      }
    } catch (e) { /* ignore */ }
    return 'external';
  }

  // Candidates matching the current type + name filters
  function getVisibleCandidates() {
    const nf = nameFilter.toLowerCase().trim();
    return candidates.filter(c => {
      if (candidateTypeFilter !== 'all' && c.candidateType !== candidateTypeFilter) return false;
      if (nf && !(c.name || '').toLowerCase().includes(nf)) return false;
      return true;
    });
  }

  // ══════════════════════════════════════════════════════
  // PARALLEL + RETRY
  // ══════════════════════════════════════════════════════

  async function parallelBatch(items, asyncFn, concurrency = 5) {
    const results = new Array(items.length);
    let nextIndex = 0;
    async function worker() {
      while (nextIndex < items.length) { const i = nextIndex++; results[i] = await asyncFn(items[i], i); }
    }
    await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, () => worker()));
    return results;
  }

  async function withRetry(fn, { retries = 3, baseDelay = 500, label = '' } = {}) {
    for (let attempt = 1; attempt <= retries; attempt++) {
      try { return await fn(); } catch (err) {
        if (attempt === retries) throw err;
        await new Promise(r => setTimeout(r, baseDelay * Math.pow(2, attempt - 1)));
      }
    }
  }

  // ══════════════════════════════════════════════════════
  // API CALLS
  // ══════════════════════════════════════════════════════

  async function fetchAllCandidates(liveJobUuid, journeyId, stageIds = [], statusIds = [], maxCandidates = 0, startOffset = 0, keyword = '') {
    const subdomain = getSubdomain();
    const limit = 25;
    const stageFilter = stageIds.length > 0 ? JSON.stringify(stageIds) : '[]';
    const statusFilter = statusIds.length > 0 ? JSON.stringify(statusIds) : '[]';
    const pageUrl = (offset) => `https://${subdomain}.paradox.ai/api/job-centric-view/get-candidates-by-stage?live_job_uuid=${liveJobUuid}&keyword=${encodeURIComponent(keyword)}&stage_ids=${encodeURIComponent(stageFilter)}&status_ids=${encodeURIComponent(statusFilter)}&journey_id=${journeyId}&offset=${offset}&limit=${limit}&order_type=0&time_filter=4&is_previous=${isPrevious}`;

    const fetchPage = async (offset) => {
      let retries = 3;
      while (retries > 0) {
        try {
          const resp = await fetch(pageUrl(offset), { credentials: 'include', headers: apiHeaders() });
          if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
          return await resp.json();
        } catch (err) {
          retries--;
          if (retries === 0) throw new Error(`Failed at offset ${offset}: ${err.message}`);
          await new Promise(r => setTimeout(r, 1500));
        }
      }
    };

    // First page tells us the total; remaining pages fetch in waves of 3.
    // Note: `total` can overcount when stage/status/keyword filters apply,
    // so we also stop as soon as any page comes back empty.
    const first = await fetchPage(startOffset);
    const total = first.total || 0;
    const all = [...(first.candidates || [])];
    const targetCount = maxCandidates > 0
      ? Math.min(maxCandidates, Math.max(0, total - startOffset))
      : Math.max(0, total - startOffset);
    updateStatus(`Found ${all.length} candidates...`);

    const maxOffset = startOffset + Math.ceil(targetCount / limit) * limit;
    let offset = startOffset + limit;
    let done = all.length === 0 || (first.candidates || []).length < limit;
    while (!done && offset < maxOffset && (maxCandidates === 0 || all.length < maxCandidates)) {
      const wave = [];
      for (let i = 0; i < 3 && offset < maxOffset; i++, offset += limit) wave.push(offset);
      if (!wave.length) break;
      const pages = await parallelBatch(wave, fetchPage, 3);
      for (const d of pages) {
        const batch = d.candidates || [];
        all.push(...batch);
        if (batch.length < limit) done = true; // ran out of filtered results
      }
      updateStatus(`Found ${maxCandidates > 0 ? Math.min(all.length, maxCandidates) : all.length} candidates...`);
    }
    if (maxCandidates > 0 && all.length > maxCandidates) all.length = maxCandidates;
    return { candidates: all, total };
  }

  async function fetchLeadData(candidateUuid) {
    const subdomain = getSubdomain();
    const url = `https://${subdomain}.paradox.ai/api/lead/${candidateUuid}?support_auto_translation=0&no_perm_raise=0&with_candidate_summary_data=1&with_integration_message=1`;
    const resp = await fetch(url, { credentials: 'include', headers: { ...apiHeaders(), 'referer': window.location.href, 'cache-control': 'no-cache' } });

    if (!resp.ok) {
      const cemResp = await fetch(`https://${subdomain}.paradox.ai/api/lead/cem-xhr`, {
        method: 'PUT', credentials: 'include',
        headers: { ...apiHeaders(), 'content-type': 'application/json', 'referer': window.location.href },
        body: JSON.stringify({ candidate_uuid: candidateUuid, latest_message_id: 0, unsubscribed: 0, is_live: 0, with_candidate_summary_data: 1, support_auto_translation: 0, page_type: '' })
      });
      if (!cemResp.ok) throw new Error(`Lead: ${resp.status}, cem-xhr: ${cemResp.status}`);
      return cemResp.json();
    }
    return resp.json();
  }

  async function fetchResumeUrl(docUuid) {
    const resp = await fetch(`https://${getSubdomain()}.paradox.ai/document/user/${docUuid.replace(/-/g, '')}?document_type=1`, { credentials: 'include', headers: apiHeaders() });
    if (!resp.ok) throw new Error(`Doc: ${resp.status}`);
    const d = await resp.json();
    if (d.success && d.document_url) return d.document_url;
    throw new Error('No doc URL');
  }

  async function fetchPdfBytes(candidate) {
    let url;
    if (candidate.fileUrl) url = candidate.fileUrl + (candidate.fileUrl.includes('?') ? '&' : '?') + 'is_download=true';
    else if (candidate.resumeUuid) url = await fetchResumeUrl(candidate.resumeUuid);
    const resp = await fetch(url, { credentials: 'include' });
    if (!resp.ok) throw new Error(`PDF: ${resp.status}`);
    return resp.arrayBuffer();
  }

  async function dispositionCandidate(uuid, stageId, statusId, nextStepId) {
    const body = { action: 'edit_candidate_journey_status', stage_id: stageId, status_id: statusId };
    if (nextStepId) { body.move_status_from_nextstep = true; body.next_step_id = nextStepId; }
    const resp = await fetch(`https://${getSubdomain()}.paradox.ai/api/lead/${uuid}`, {
      method: 'PUT', credentials: 'include',
      headers: { ...apiHeaders(), 'content-type': 'application/json', 'referer': window.location.href },
      body: JSON.stringify(body)
    });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const data = await resp.json();
    if (data.error && data.error.length > 0) throw new Error(data.error);
    return data;
  }

  async function fetchNextSteps(uuid, stageId, statusId) {
    const resp = await fetch(`https://${getSubdomain()}.paradox.ai/api/lead/${uuid}/check-journey-next-steps?stage_id=${stageId}&status_id=${statusId}&get_action_needed_statuses=0`, { credentials: 'include', headers: apiHeaders() });
    if (!resp.ok) return null;
    return resp.json();
  }


  // ══════════════════════════════════════════════════════
  // PLATFORM ADAPTER
  // ══════════════════════════════════════════════════════
  // Maps Paradox onto the normalized candidate shape used by the shared
  // engine (scan/select UI, parallelBatch, zip/merge, download).

  const ParadoxAdapter = {
    id: 'paradox',
    title: 'Paradox Tools',
    navHint: 'Navigate to a job Centric View first.',
    supportsDisposition: true,
    supportsPrevious: true,
    supportsDeepSearch: true,
    supportsLeadEnrichment: true,
    getContext() { return getPageContext(); },
    contextReady(ctx) { return !!(ctx.liveJobUuid && ctx.journeyId); },
    loadStages() { return loadParadoxStages(); },
    confidentialBadge() { return null; },
    async collectCandidates({ ctx, filter, limit, offset, keyword }) {
      const result = await fetchAllCandidates(ctx.liveJobUuid, ctx.journeyId, filter.stageIds, filter.statusIds, limit, offset, keyword);

      // Reset the lead cache when the job or opening type changes
      const cacheKey = ctx.liveJobUuid + '|' + isPrevious;
      if (leadCacheKey !== cacheKey) { leadCache.clear(); leadCacheKey = cacheKey; }

      // Build candidates straight from list data — no per-candidate calls.
      // Resume checks happen at download time, only for selected candidates.
      const mapped = result.candidates.map(c => {
        const cjs = c.candidate_journey_status || {};
        const rec = {
          uuid: c.uuid, name: c.name || `${c.first_name} ${c.last_name}`, email: c.email || '',
          hasResume: null, resumeUuid: null, fileUrl: null, fileName: null,
          jobName: c.candidate_profile_job_name || '',
          currentStageId: cjs.stage_id, currentStatusId: cjs.status_id,
          currentStageName: cjs.status_name || '', currentJourneyName: cjs.journey_name || '',
          candidateType: extractCandidateType(c)
        };
        // If this candidate's resume was already checked this session, reuse it
        const hit = leadCache.get(c.uuid);
        if (hit) Object.assign(rec, hit);
        return rec;
      });

      // Journey stage catalog: prefer list data, fall back to one lead fetch
      if (journeyStages.length === 0) {
        const catalogSrc = result.candidates.find(c => (c.candidate_journey_statuses || []).length > 0);
        if (catalogSrc) journeyStages = catalogSrc.candidate_journey_statuses;
      }
      if (journeyStages.length === 0 && mapped.length > 0) {
        try {
          const ld = await fetchLeadData(mapped[0].uuid);
          if (ld.candidate_journey_statuses?.length > 0) journeyStages = ld.candidate_journey_statuses;
        } catch (e) { /* dropdown falls back to status ids */ }
      }

      return { candidates: mapped, total: result.total };
    },
    fetchPdfBytes(candidate) { return fetchPdfBytes(candidate); }
  };

  const ADAPTER = ParadoxAdapter;

  function loadStages() { return ADAPTER.loadStages(); }

  // ══════════════════════════════════════════════════════
  // STAGE DISCOVERY
  // ══════════════════════════════════════════════════════

  async function loadParadoxStages() {
    const ctx = getPageContext();
    if (!ctx.liveJobUuid || !ctx.journeyId || stagesLoaded) return;

    isLoadingStages = true;
    renderPanel();

    try {
      const subdomain = getSubdomain();
      const probeUrl = `https://${subdomain}.paradox.ai/api/job-centric-view/get-candidates-by-stage?live_job_uuid=${ctx.liveJobUuid}&keyword=&stage_ids=[]&status_ids=[]&journey_id=${ctx.journeyId}&offset=0&limit=1&order_type=0&time_filter=4&is_previous=${isPrevious}`;
      const probeResp = await fetch(probeUrl, { credentials: 'include', headers: apiHeaders() });
      if (probeResp.ok) {
        const probeData = await probeResp.json();
        if (probeData.candidates?.length > 0) {
          const probeLead = await withRetry(() => fetchLeadData(probeData.candidates[0].uuid), { retries: 3, baseDelay: 800, label: 'probe' });
          if (probeLead.candidate_journey_statuses?.length > 0) {
            journeyStages = probeLead.candidate_journey_statuses;
            stagesLoaded = true;

            // Build filter options by finding matching stages/statuses
            const findStage = (name) => journeyStages.find(s => s.stage_name === name);
            const findStatus = (stageName, statusName) => {
              const stg = findStage(stageName);
              if (!stg) return null;
              const st = stg.statuses?.find(s => s.status_name === statusName);
              return st ? { stageId: stg.stage_id, statusId: st.status_id } : null;
            };

            scanFilterOptions = [];

            // All Stages (no filter)
            scanFilterOptions.push({ label: 'All Stages', stageIds: [], statusIds: [] });

            // Candidate Review (status within Candidate Review stage)
            const cr = findStatus('Candidate Review', 'Candidate Review');
            if (cr) scanFilterOptions.push({ label: 'Candidate Review', stageIds: [cr.stageId], statusIds: [cr.statusId] });

            // Meets Minimum Qualifications (status within Candidate Review stage)
            const mmq = findStatus('Candidate Review', 'Meets Minimum Qualifications');
            if (mmq) scanFilterOptions.push({ label: 'Meets Minimum Qualifications', stageIds: [mmq.stageId], statusIds: [mmq.statusId] });

            // Recruiter Screen (entire stage)
            const rs = findStage('Recruiter Interview');
            if (rs) scanFilterOptions.push({ label: 'Recruiter Screen', stageIds: [rs.stage_id], statusIds: [] });

            // Manager Screen (entire stage)
            const ms = findStage('Manager Interview');
            if (ms) scanFilterOptions.push({ label: 'Manager Screen', stageIds: [ms.stage_id], statusIds: [] });

            // Manager Panel (entire stage)
            const mp = findStage('Manager Panel Interview');
            if (mp) scanFilterOptions.push({ label: 'Manager Panel', stageIds: [mp.stage_id], statusIds: [] });

            // Default: Candidate Review for disposition, first option for resumes
            if (activeTab === 'disposition') {
              selectedFilterIndex = 0; // Candidate Review
            } else {
              selectedFilterIndex = 0;
            }
          }
        }
      }
    } catch (e) {
      console.warn('[Paradox Tools] Could not load stages:', e);
    }

    isLoadingStages = false;
    renderPanel();
  }

  // ══════════════════════════════════════════════════════
  // SCAN
  // ══════════════════════════════════════════════════════

  function updateStatus(msg) { const el = panel?.querySelector('#prbd-status'); if (el) el.textContent = msg; }

  function runKeywordScan(kw) {
    scanKeyword = kw;
    nameFilter = '';
    scanOffset = 0;
    selectedFilterIndex = 0; // search across all stages
    scanForCandidates();
  }

  async function scanForCandidates() {
    const ctx = ADAPTER.getContext();
    if (!ADAPTER.contextReady(ctx)) { alert(ADAPTER.navHint); return; }

    isScanning = true; candidates = []; selectedIds.clear();
    nextStepsData = null; selectedNextStepId = null; selectedStatusId = null;
    downloadProgress = { done: 0, total: 0, errors: [] };
    disposeProgress = { done: 0, total: 0, errors: [] };
    nameFilter = ''; dlStatus = '';
    renderPanel();

    try {
      // Use the selected filter
      const filter = scanFilterOptions[selectedFilterIndex] || { label: 'All', stageIds: [], statusIds: [] };
      const limitLabel = scanLimit > 0 ? ` (max ${scanLimit})` : '';
      const kwLabel = scanKeyword.trim() ? ` named "${scanKeyword.trim()}"` : '';
      updateStatus(`Fetching ${filter.label} candidates${kwLabel}${limitLabel}...`);

      const result = await ADAPTER.collectCandidates({ ctx, filter, limit: scanLimit, offset: scanOffset, keyword: scanKeyword.trim() });
      totalAvailable = result.total;
      candidates = result.candidates;
      track('scan', { tab: activeTab, opening: isPrevious ? 'previous' : 'current', count: candidates.length });
    } catch (err) {
      console.error('[Paradox Tools] Scan failed:', err);
      track('scan', { tab: activeTab, opening: isPrevious ? 'previous' : 'current', count: 0, errors: 1 });
      alert(`Scan failed: ${err.message}`);
    }

    // Fetch next-steps from the first candidate that has a current stage/status
    const sampleCandidate = ADAPTER.supportsDisposition ? candidates.find(c => c.currentStageId && c.currentStatusId) : null;
    if (sampleCandidate) {
      console.log('[Paradox Tools] Sample candidate for next-steps:', sampleCandidate?.name, 'stageId:', sampleCandidate?.currentStageId, 'statusId:', sampleCandidate?.currentStatusId);
      try {
        updateStatus('Loading disposition options...');
        const ns = await fetchNextSteps(sampleCandidate.uuid, sampleCandidate.currentStageId, sampleCandidate.currentStatusId);
        if (ns?.success && ns.next_steps) {
          nextStepsData = ns.next_steps;
          console.log('[Paradox Tools] Next steps loaded:', nextStepsData);
        }
      } catch (e) {
        console.warn('[Paradox Tools] Could not load next steps:', e);
      }
    }

    if (candidates.length > 0) setupOpen = false;
    isScanning = false; renderPanel();
  }

  // ══════════════════════════════════════════════════════
  // RESUME DOWNLOAD
  // ══════════════════════════════════════════════════════

  function updateDlStatus(msg) { dlStatus = msg; const el = panel?.querySelector('#prbd-dl-status'); if (el) el.textContent = msg; }

  async function downloadAsFolder(list) {
    const zip = new JSZip(); let n = 0;
    await parallelBatch(list, async (c) => {
      try {
        const bytes = await withRetry(() => ADAPTER.fetchPdfBytes(c), { retries: 3, baseDelay: 500, label: c.name });
        zip.file(candidateFilename(c.name, c.fileExt), bytes);
        n++; downloadProgress.done = n;
        updateDlStatus(`Fetched ${c.name}`);
      } catch (err) { n++; downloadProgress.done = n; downloadProgress.errors.push(`${c.name}: ${err.message}`); }
      renderPanel();
    }, 5);
    updateDlStatus('Zipping...');
    const blob = await zip.generateAsync({ type: 'blob' }, m => updateDlStatus(`Zipping... ${Math.round(m.percent)}%`));
    triggerDownload(blob, `Resumes_${new Date().toISOString().slice(0, 10)}.zip`);
  }

  async function downloadAsMerged(list, outputName) {
    const { PDFDocument } = PDFLib;
    const merged = await PDFDocument.create();
    let fetched = 0, mergeN = 0;

    for (let i = 0; i < list.length; i += 20) {
      const chunk = list.slice(i, i + 20);
      updateDlStatus(`Batch ${Math.floor(i/20)+1}/${Math.ceil(list.length/20)}: fetching...`);
      const results = await parallelBatch(chunk, async (c) => {
        try {
          const bytes = await withRetry(() => ADAPTER.fetchPdfBytes(c), { retries: 3, baseDelay: 500, label: c.name });
          fetched++; downloadProgress.done = fetched; renderPanel();
          return { name: c.name, bytes };
        } catch (err) {
          fetched++; downloadProgress.done = fetched;
          downloadProgress.errors.push(`${c.name}: ${err.message}`);
          renderPanel(); return { name: c.name, bytes: null };
        }
      }, 5);

      for (const r of results) {
        if (!r.bytes) continue;
        try {
          mergeN++; updateDlStatus(`Merging ${mergeN}: ${r.name}...`);
          const donor = await PDFDocument.load(r.bytes, { ignoreEncryption: true });
          (await merged.copyPages(donor, donor.getPageIndices())).forEach(p => merged.addPage(p));
        } catch (e) { downloadProgress.errors.push(`${r.name}: Invalid PDF`); }
      }
    }

    updateDlStatus(`Saving (${merged.getPageCount()} pages)...`);
    triggerDownload(new Blob([await merged.save()], { type: 'application/pdf' }),
      outputName || `All_Resumes_${new Date().toISOString().slice(0, 10)}.pdf`);
  }

  function triggerDownload(blob, name) {
    const u = URL.createObjectURL(blob);
    const a = Object.assign(document.createElement('a'), { href: u, download: name });
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(u), 10000);
  }

  function promptMergedFilename() {
    const defaultName = `All_Resumes_${new Date().toISOString().slice(0, 10)}`;
    const input = prompt('Name the merged PDF file:', defaultName);
    if (input === null) return null; // user cancelled
    let name = input.trim().replace(/[\\/:*?"<>|]/g, '').replace(/\.pdf$/i, '');
    if (!name) name = defaultName;
    return name + '.pdf';
  }

  async function downloadSelected() {
    const chosen = getVisibleCandidates().filter(c => selectedIds.has(c.uuid) && c.hasResume !== false);
    if (!chosen.length) return;
    const confidentialNote = ADAPTER.confidentialBadge();
    if (confidentialNote && !confirm(confidentialNote + '\n\nDownload ' + chosen.length + ' resume' + (chosen.length > 1 ? 's' : '') + ' from this confidential requisition?')) return;
    let mergedName = null;
    if (downloadMode === 'merged') {
      mergedName = promptMergedFilename();
      if (mergedName === null) return; // cancelled, abort download
    }
    isDownloading = true; dlStatus = '';
    downloadProgress = { done: 0, total: chosen.length, errors: [], skipped: [] };
    renderPanel();

    // Phase A: resolve resume info for selected candidates (cached per session)
    let resolved = 0;
    await parallelBatch(chosen, async (c) => {
      if (c.hasResume === true && (c.resumeUuid || c.fileUrl)) { resolved++; return; }
      if (!ADAPTER.supportsLeadEnrichment) { resolved++; return; }
      let info = leadCache.get(c.uuid);
      if (!info) {
        try {
          const ld = await withRetry(() => fetchLeadData(c.uuid), { retries: 3, baseDelay: 800, label: c.name });
          const lead = ld.lead || {};
          const att = lead.attachments || [];
          const resume = att.find(a => a.resume_id || a.file_name?.toLowerCase().endsWith('.pdf'));
          info = {
            hasResume: !!resume, resumeUuid: resume?.uuid || resume?.resume_uuid || null,
            fileUrl: resume?.file_url || null, fileName: resume?.file_name || null
          };
          leadCache.set(c.uuid, info);
        } catch (err) {
          // not cached, so a later retry can succeed
          info = { hasResume: false, resumeUuid: null, fileUrl: null, fileName: null };
        }
      }
      Object.assign(c, info);
      resolved++;
      updateDlStatus(`Checking resumes: ${resolved} of ${chosen.length}...`);
    }, 5);

    const list = chosen.filter(c => c.hasResume && (c.resumeUuid || c.fileUrl));
    downloadProgress.skipped = chosen.filter(c => !(c.hasResume && (c.resumeUuid || c.fileUrl))).map(c => c.name);
    downloadProgress.total = list.length;

    if (!list.length) {
      isDownloading = false; dlStatus = '';
      renderPanel();
      alert('None of the selected candidates have a resume on file.');
      return;
    }
    renderPanel();

    if (downloadMode === 'merged') await downloadAsMerged(list, mergedName); else await downloadAsFolder(list);
    const dlErrors = (downloadProgress.errors || []).length;
    track('resume_download', {
      tab: activeTab, opening: isPrevious ? 'previous' : 'current',
      format: downloadMode === 'merged' ? 'merged' : 'zip',
      count: Math.max(0, list.length - dlErrors), errors: dlErrors
    });
    isDownloading = false; renderPanel();
  }

  // ══════════════════════════════════════════════════════
  // BULK DISPOSITION
  // ══════════════════════════════════════════════════════

  async function bulkDisposition() {
    if (!selectedNextStepId || !selectedStatusId) { alert('Select an action and status first.'); return; }
    const list = getVisibleCandidates().filter(c => selectedIds.has(c.uuid) && !c.error);
    if (!list.length) return;

    // Look up the step and resolve the stage_id for the selected status
    const step = nextStepsData.find(s => s.id === selectedNextStepId);
    if (!step) return;

    // Find which stage this status belongs to
    let targetStageId = step.stages?.[0]; // default to first stage
    for (const stg of journeyStages) {
      if (stg.statuses?.find(s => s.status_id === selectedStatusId)) {
        if (step.stages.includes(stg.stage_id)) {
          targetStageId = stg.stage_id;
          break;
        }
      }
    }

    const statusLabel = (() => {
      for (const stg of journeyStages) {
        const st = stg.statuses?.find(s => s.status_id === selectedStatusId);
        if (st) return st.status_name;
      }
      return `Status ${selectedStatusId}`;
    })();

    if (!confirm(`Move ${list.length} candidate${list.length > 1 ? 's' : ''} to:\n\n${step.button_label}: ${statusLabel}\n\nContinue?`)) return;

    isDisposing = true; disposeProgress = { done: 0, total: list.length, errors: [] }; renderPanel();

    const conc = list.length > 300 ? 3 : list.length > 100 ? 4 : 5;
    await parallelBatch(list, async (c) => {
      try {
        await withRetry(() => dispositionCandidate(c.uuid, targetStageId, selectedStatusId, step.id),
          { retries: 3, baseDelay: 800, label: c.name });
        disposeProgress.done++;
        leadCache.delete(c.uuid); // stage changed; force fresh check next scan
      } catch (err) { disposeProgress.done++; disposeProgress.errors.push(`${c.name}: ${err.message}`); }
      renderPanel();
    }, conc);

    track('disposition', {
      tab: activeTab, opening: isPrevious ? 'previous' : 'current',
      count: Math.max(0, disposeProgress.done - disposeProgress.errors.length),
      errors: disposeProgress.errors.length
    });
    isDisposing = false; renderPanel();
  }

  // ══════════════════════════════════════════════════════
  // UI
  // ══════════════════════════════════════════════════════

  function createPanel() {
    panel = document.createElement('div');
    panel.id = 'prbd-panel';
    document.body.appendChild(panel);
    renderPanel();
  }

  function renderPanel() {
    if (!panel) return;
    const visible = getVisibleCandidates();
    const selectable = activeTab === 'resumes'
      ? visible.filter(c => c.hasResume !== false && !c.error)
      : visible.filter(c => !c.error);
    const selCount = [...selectedIds].filter(id => selectable.find(c => c.uuid === id)).length;
    const internalCount = candidates.filter(c => c.candidateType === 'internal').length;
    const externalCount = candidates.filter(c => c.candidateType === 'external').length;
    const ctx = ADAPTER.getContext();
    const ctxReady = ADAPTER.contextReady(ctx);
    const busy = isScanning || isDownloading || isDisposing;

    panel.innerHTML = `
      <div class="prbd-header">
        <div class="prbd-title">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
          </svg>
          ${ADAPTER.title}
        </div>
        <button class="prbd-close" id="prbd-close">&times;</button>
      </div>

      <div class="prbd-tabs">
        <button class="prbd-tab ${activeTab === 'resumes' ? 'prbd-tab-active' : ''}" data-tab="resumes" ${busy ? 'disabled' : ''}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
            <polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
          </svg>
          Resumes
        </button>
        ${ADAPTER.supportsDisposition ? `
        <button class="prbd-tab ${activeTab === 'disposition' ? 'prbd-tab-active' : ''}" data-tab="disposition" ${busy ? 'disabled' : ''}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="9 11 12 14 22 4"/>
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
          </svg>
          Disposition
        </button>` : ''}
      </div>

      <div class="prbd-body">
        ${!isScanning && (setupOpen || (candidates.length === 0 && !scanKeyword.trim())) ? `
          <div class="prbd-setup">
            <div class="prbd-setup-title">Scan Setup</div>
            ${ADAPTER.supportsPrevious ? `
            <div class="prbd-opening-toggle">
              <button class="prbd-opening-btn ${!isPrevious ? 'prbd-opening-active' : ''}" data-previous="false" ${busy ? 'disabled' : ''}>Current Opening</button>
              <button class="prbd-opening-btn ${isPrevious ? 'prbd-opening-active' : ''}" data-previous="true" ${busy ? 'disabled' : ''}>Previous Openings</button>
            </div>` : ''}
            ${ADAPTER.confidentialBadge() ? `<div class="prbd-keyword-chip prbd-confidential"><span>&#9888; ${ADAPTER.confidentialBadge()}</span></div>` : ''}
            ${stagesLoaded ? `
              <div class="prbd-scan-filters">
                <div class="prbd-form-group prbd-stage-picker">
                  <label class="prbd-form-label">Candidates In</label>
                  <select class="prbd-select" id="prbd-scan-stage-select">
                    ${scanFilterOptions.map((f, i) =>
                      `<option value="${i}" ${selectedFilterIndex === i ? 'selected' : ''}>${f.label}</option>`
                    ).join('')}
                  </select>
                </div>
                <div class="prbd-form-group prbd-limit-picker">
                  <label class="prbd-form-label">Limit</label>
                  <select class="prbd-select" id="prbd-scan-limit">
                    <option value="0" ${scanLimit === 0 ? 'selected' : ''}>All</option>
                    <option value="25" ${scanLimit === 25 ? 'selected' : ''}>25</option>
                    <option value="50" ${scanLimit === 50 ? 'selected' : ''}>50</option>
                    <option value="100" ${scanLimit === 100 ? 'selected' : ''}>100</option>
                    <option value="200" ${scanLimit === 200 ? 'selected' : ''}>200</option>
                  </select>
                </div>
              </div>
            ` : ''}
            ${isLoadingStages ? '<p class="prbd-hint">Loading stages...</p>' : ''}
            ${scanKeyword.trim() ? `
              <div class="prbd-keyword-chip">
                <span>Name search: &ldquo;${scanKeyword.trim().replace(/</g,'&lt;')}&rdquo;</span>
                <button class="prbd-chip-x" id="prbd-clear-keyword-setup" title="Clear keyword">&times;</button>
              </div>
            ` : ''}
            <button class="prbd-btn prbd-btn-scan" id="prbd-scan" ${busy || isLoadingStages || !ctxReady ? 'disabled' : ''}>
              ${candidates.length > 0 ? 'Re-scan' : 'Scan for Candidates'}
            </button>
            ${!ctxReady ? `<p class="prbd-hint" style="text-align:center">${ADAPTER.navHint}</p>` : ''}
          </div>
        ` : ''}

        ${!isScanning && !setupOpen && candidates.length > 0 ? (() => {
          const filter = scanFilterOptions[selectedFilterIndex] || { label: 'All Stages' };
          const parts = [filter.label, isPrevious ? 'Previous' : 'Current'];
          if (scanKeyword.trim()) parts.push('"' + scanKeyword.trim() + '"');
          return `
          <div class="prbd-setup-summary">
            <span class="prbd-setup-summary-text" title="${parts.join(' · ')}">${parts.join(' &middot; ')}</span>
            <button class="prbd-link-btn" id="prbd-edit-setup" ${busy ? 'disabled' : ''}>Edit</button>
          </div>`;
        })() : ''}

        ${!isScanning && candidates.length === 0 && scanKeyword.trim() ? `
          <div class="prbd-empty">
            <p>No candidates named &ldquo;${scanKeyword.trim().replace(/</g,'&lt;')}&rdquo;</p>
            <div class="prbd-keyword-chip" style="margin-top:8px">
              <span>Name search: &ldquo;${scanKeyword.trim().replace(/</g,'&lt;')}&rdquo;</span>
              <button class="prbd-chip-x" id="prbd-clear-keyword" title="Clear keyword and re-scan">&times;</button>
            </div>
          </div>
        ` : ''}

        ${isScanning ? `<div class="prbd-scanning"><div class="prbd-spinner"></div><p id="prbd-status">Starting scan...</p></div>` : ''}

        ${!isScanning && candidates.length > 0 ? `
            <div class="prbd-search-wrap">
              <svg class="prbd-search-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
              <input type="text" class="prbd-input prbd-search-input" id="prbd-name-filter" placeholder="Search candidates by name..." value="${nameFilter.replace(/"/g, '&quot;')}" ${busy ? 'disabled' : ''}>
            </div>
            ${nameFilter.trim() && !busy && ADAPTER.supportsDeepSearch ? `
              <button class="prbd-deep-search" id="prbd-deep-search">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                Search entire req for &ldquo;${nameFilter.trim().replace(/</g,'&lt;')}&rdquo; <span class="prbd-label-hint">all stages &middot; Enter</span>
              </button>
            ` : ''}
            ${scanKeyword.trim() ? `
              <div class="prbd-keyword-chip">
                <span>Name search: &ldquo;${scanKeyword.trim().replace(/</g,'&lt;')}&rdquo;</span>
                <button class="prbd-chip-x" id="prbd-clear-keyword" title="Clear keyword and re-scan" ${busy ? 'disabled' : ''}>&times;</button>
              </div>
            ` : ''}
            <div class="prbd-type-toggle">
              <button class="prbd-type-btn ${candidateTypeFilter === 'all' ? 'prbd-type-active' : ''}" data-type="all" ${busy ? 'disabled' : ''}>All<span class="prbd-type-count">${candidates.length}</span></button>
              <button class="prbd-type-btn ${candidateTypeFilter === 'internal' ? 'prbd-type-active prbd-type-active-int' : ''}" data-type="internal" ${busy ? 'disabled' : ''}>Internal<span class="prbd-type-count">${internalCount}</span></button>
              <button class="prbd-type-btn ${candidateTypeFilter === 'external' ? 'prbd-type-active' : ''}" data-type="external" ${busy ? 'disabled' : ''}>External<span class="prbd-type-count">${externalCount}</span></button>
            </div>
            <div class="prbd-toolbar">
              <label class="prbd-select-all"><input type="checkbox" id="prbd-select-all" ${selCount === selectable.length && selectable.length > 0 ? 'checked' : ''} ${busy ? 'disabled' : ''}> ${selCount > 0 ? selCount + ' selected' : 'Select all (' + selectable.length + ')'}</label>
              ${visible.length < candidates.length ? `<span class="prbd-hint">${visible.length} of ${candidates.length} shown</span>` : ''}
            </div>
            ${scanLimit > 0 && totalAvailable > scanLimit ? `
              <div class="prbd-pagination">
                <button class="prbd-btn prbd-btn-page" id="prbd-prev" ${scanOffset === 0 || busy ? 'disabled' : ''}>&larr; Prev</button>
                <span class="prbd-page-info">${scanOffset + 1}&ndash;${Math.min(scanOffset + scanLimit, totalAvailable)} of ${totalAvailable}</span>
                <button class="prbd-btn prbd-btn-page" id="prbd-next" ${scanOffset + scanLimit >= totalAvailable || busy ? 'disabled' : ''}>Next &rarr;</button>
              </div>
            ` : ''}
            <div class="prbd-list">
              ${visible.length === 0 ? '<p class="prbd-hint" style="padding:12px 0;text-align:center">No candidates match the current filters.</p>' : ''}
              ${visible.map(c => {
                const dis = activeTab === 'resumes' ? (c.hasResume === false || !!c.error) : !!c.error;
                const tag = c.error ? '<span class="prbd-row-tag prbd-tag-err">Error</span>'
                  : activeTab === 'resumes' && c.hasResume === false ? '<span class="prbd-row-tag prbd-tag-err">No resume</span>'
                  : activeTab === 'disposition' && c.currentStageName ? `<span class="prbd-row-tag" title="${c.currentStageName}">${c.currentStageName}</span>`
                  : '';
                return `<div class="prbd-candidate ${dis ? 'prbd-no-resume' : ''}"><label>
                  <input type="checkbox" data-uuid="${c.uuid}" ${dis ? 'disabled' : ''} ${selectedIds.has(c.uuid) ? 'checked' : ''}>
                  <span class="prbd-candidate-name" title="${c.name}">${c.name}</span>
                  ${c.candidateType === 'internal' ? '<span class="prbd-internal-tag">INT</span>' : ''}
                  ${tag}
                </label></div>`;
              }).join('')}
            </div>
        ` : ''}

        ${activeTab === 'resumes' && isDownloading ? `<div class="prbd-progress">
          <div class="prbd-progress-bar"><div class="prbd-progress-fill" style="width:${Math.round((downloadProgress.done/downloadProgress.total)*100)}%"></div></div>
          <p><strong>${Math.round((downloadProgress.done/downloadProgress.total)*100)}%</strong> &middot; ${downloadProgress.done} / ${downloadProgress.total} resumes</p>
          <p id="prbd-dl-status" class="prbd-hint">${dlStatus}</p>
          ${(downloadProgress.skipped || []).length ? `<p class="prbd-hint">Skipped (no resume): ${downloadProgress.skipped.join(', ')}</p>` : ''}
          ${downloadProgress.errors.length ? `<div class="prbd-errors">${downloadProgress.errors.map(e=>`<p class="prbd-error">${e}</p>`).join('')}</div>` : ''}
        </div>` : ''}
        ${activeTab === 'resumes' && !isDownloading && downloadProgress.done > 0 ? `<div class="prbd-done">&#10003; ${downloadProgress.done - downloadProgress.errors.length} of ${downloadProgress.total} downloaded${downloadProgress.errors.length ? `<br><span class="prbd-error">${downloadProgress.errors.length} failed</span>` : ''}${(downloadProgress.skipped || []).length ? `<br><span class="prbd-hint">${downloadProgress.skipped.length} skipped (no resume): ${downloadProgress.skipped.join(', ')}</span>` : ''}</div>` : ''}

        ${activeTab === 'disposition' && isDisposing ? `<div class="prbd-progress">
          <div class="prbd-progress-bar"><div class="prbd-progress-fill" style="width:${(disposeProgress.done/disposeProgress.total)*100}%"></div></div>
          <p>${disposeProgress.done} / ${disposeProgress.total} dispositioned</p>
          ${disposeProgress.errors.length ? `<div class="prbd-errors">${disposeProgress.errors.map(e=>`<p class="prbd-error">${e}</p>`).join('')}</div>` : ''}
        </div>` : ''}
        ${activeTab === 'disposition' && !isDisposing && disposeProgress.done > 0 ? `<div class="prbd-done">&#10003; ${disposeProgress.done - disposeProgress.errors.length} of ${disposeProgress.total} moved${disposeProgress.errors.length ? `<br><span class="prbd-error">${disposeProgress.errors.length} failed</span>` : ''}</div>` : ''}
      </div>

      ${!isScanning && candidates.length > 0 && ((activeTab === 'resumes' && selectable.length > 0 && !isDownloading) || (activeTab === 'disposition' && !isDisposing)) ? `
      <div class="prbd-actions">
        ${activeTab === 'resumes' && selectable.length > 0 && !isDownloading ? `
          <div class="prbd-form-label prbd-mode-label">Download as</div>
          <div class="prbd-mode-toggle">
            <button class="prbd-mode-btn ${downloadMode === 'folder' ? 'prbd-mode-active' : ''}" data-mode="folder">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg> Zip File
            </button>
            <button class="prbd-mode-btn ${downloadMode === 'merged' ? 'prbd-mode-active' : ''}" data-mode="merged">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg> Merged PDF
            </button>
          </div>
          <div class="prbd-action-btns">
            <button class="prbd-btn prbd-btn-download" id="prbd-download" ${selCount === 0 ? 'disabled' : ''}>
              ${downloadMode === 'merged' ? 'Merge' : 'Download Zip'}${selCount > 0 ? ` (${selCount})` : ''}
            </button>
          </div>
        ` : ''}

        ${activeTab === 'disposition' && !isDisposing ? `
          <div class="prbd-disposition-form">
            ${nextStepsData && nextStepsData.length > 0 ? (() => {
              // Build flat list of all status options with their parent step info
              const allOptions = [];
              for (const step of nextStepsData) {
                if (step.disabled) continue;
                for (const sid of step.statuses) {
                  let statusLabel = 'Status ' + sid;
                  let stageId = step.stages?.[0];
                  for (const stg of journeyStages) {
                    const st = stg.statuses?.find(s => s.status_id === sid);
                    if (st) { statusLabel = st.status_name; if (step.stages.includes(stg.stage_id)) stageId = stg.stage_id; break; }
                  }
                  allOptions.push({ sid, statusLabel, stepId: step.id, stepLabel: step.button_label, stageId });
                }
              }
              // Group by step label for optgroups
              const groups = {};
              for (const o of allOptions) {
                if (!groups[o.stepLabel]) groups[o.stepLabel] = [];
                groups[o.stepLabel].push(o);
              }
              const groupKeys = Object.keys(groups);
              return '<div class="prbd-form-group"><label class="prbd-form-label">Disposition</label>' +
                '<select class="prbd-select" id="prbd-disp-select"><option value="">Select disposition...</option>' +
                groupKeys.map(g => {
                  const opts = groups[g].map(o =>
                    '<option value="' + o.stepId + ':' + o.sid + ':' + o.stageId + '"' +
                    (selectedNextStepId === o.stepId && selectedStatusId === o.sid ? ' selected' : '') +
                    '>' + o.statusLabel + '</option>'
                  ).join('');
                  return groupKeys.length > 1
                    ? '<optgroup label="' + g + '">' + opts + '</optgroup>'
                    : opts;
                }).join('') +
                '</select></div>';
            })() : `
              <p class="prbd-hint">No disposition options available for these candidates.</p>
            `}
          </div>
          <div class="prbd-action-btns">
            <button class="prbd-btn prbd-btn-dispose" id="prbd-dispose" ${selCount === 0 || !selectedNextStepId || !selectedStatusId ? 'disabled' : ''}>
              Disposition${selCount > 0 ? ` (${selCount})` : ''}
            </button>
          </div>
        ` : ''}
      </div>
      ` : ''}
    `;
    // ── Bind events ──
    panel.querySelector('#prbd-close')?.addEventListener('click', togglePanel);
    panel.querySelector('#prbd-scan')?.addEventListener('click', () => { scanOffset = 0; scanForCandidates(); });
    panel.querySelector('#prbd-download')?.addEventListener('click', downloadSelected);
    panel.querySelector('#prbd-dispose')?.addEventListener('click', bulkDisposition);

    panel.querySelector('#prbd-prev')?.addEventListener('click', () => {
      scanOffset = Math.max(0, scanOffset - scanLimit);
      scanForCandidates();
    });
    panel.querySelector('#prbd-next')?.addEventListener('click', () => {
      scanOffset += scanLimit;
      scanForCandidates();
    });

    panel.querySelectorAll('.prbd-tab').forEach(t => t.addEventListener('click', () => {
      activeTab = t.dataset.tab; selectedIds.clear(); candidates = [];
      downloadProgress = { done: 0, total: 0, errors: [] };
      disposeProgress = { done: 0, total: 0, errors: [] };
      selectedFilterIndex = 0;
      scanOffset = 0;
      nameFilter = ''; candidateTypeFilter = 'all'; dlStatus = ''; setupOpen = true; scanKeyword = '';
      renderPanel();
    }));

    panel.querySelectorAll('.prbd-mode-btn').forEach(b => b.addEventListener('click', () => { downloadMode = b.dataset.mode; renderPanel(); }));

    panel.querySelectorAll('.prbd-opening-btn').forEach(b => b.addEventListener('click', () => {
      const prev = b.dataset.previous === 'true';
      if (prev !== isPrevious) {
        isPrevious = prev;
        // Reset everything when switching opening type
        candidates = []; selectedIds.clear(); stagesLoaded = false; scanFilterOptions = [];
        selectedFilterIndex = 0; scanOffset = 0; totalAvailable = 0;
        nameFilter = ''; candidateTypeFilter = 'all'; dlStatus = ''; setupOpen = true; scanKeyword = ''; scanKeyword = '';
        nextStepsData = null; selectedNextStepId = null; selectedStatusId = null;
        downloadProgress = { done: 0, total: 0, errors: [] };
        disposeProgress = { done: 0, total: 0, errors: [] };
        renderPanel();
        // Reload stages for the new opening type
        loadStages();
      }
    }));

    panel.querySelector('#prbd-select-all')?.addEventListener('change', (e) => {
      if (e.target.checked) selectable.forEach(c => selectedIds.add(c.uuid));
      else selectable.forEach(c => selectedIds.delete(c.uuid));
      renderPanel();
    });

    panel.querySelectorAll('.prbd-candidate input[type="checkbox"]').forEach(cb => cb.addEventListener('change', (e) => {
      if (e.target.checked) selectedIds.add(e.target.dataset.uuid); else selectedIds.delete(e.target.dataset.uuid);
      renderPanel();
    }));

    panel.querySelector('#prbd-edit-setup')?.addEventListener('click', () => {
      setupOpen = true;
      renderPanel();
    });

    panel.querySelectorAll('.prbd-type-btn').forEach(b => b.addEventListener('click', () => {
      if (candidateTypeFilter !== b.dataset.type) {
        candidateTypeFilter = b.dataset.type;
        renderPanel();
      }
    }));

    panel.querySelector('#prbd-name-filter')?.addEventListener('input', (e) => {
      nameFilter = e.target.value;
      renderPanel();
      const ni = panel.querySelector('#prbd-name-filter');
      if (ni) { ni.focus(); ni.setSelectionRange(ni.value.length, ni.value.length); }
    });

    panel.querySelector('#prbd-name-filter')?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && e.target.value.trim() && ADAPTER.supportsDeepSearch) runKeywordScan(e.target.value.trim());
    });

    panel.querySelector('#prbd-deep-search')?.addEventListener('click', () => {
      if (nameFilter.trim()) runKeywordScan(nameFilter.trim());
    });

    panel.querySelector('#prbd-clear-keyword-setup')?.addEventListener('click', () => {
      scanKeyword = '';
      renderPanel();
    });

    panel.querySelector('#prbd-clear-keyword')?.addEventListener('click', () => {
      scanKeyword = '';
      scanOffset = 0;
      scanForCandidates();
    });

    panel.querySelector('#prbd-scan-stage-select')?.addEventListener('change', (e) => {
      selectedFilterIndex = parseInt(e.target.value);
      scanOffset = 0;
      renderPanel();
    });

    panel.querySelector('#prbd-scan-limit')?.addEventListener('change', (e) => {
      scanLimit = parseInt(e.target.value);
      scanOffset = 0;
      renderPanel();
    });

    panel.querySelector('#prbd-disp-select')?.addEventListener('change', (e) => {
      if (e.target.value) {
        const [stepId, statusId, stageId] = e.target.value.split(':').map(Number);
        selectedNextStepId = stepId;
        selectedStatusId = statusId;
      } else {
        selectedNextStepId = null;
        selectedStatusId = null;
      }
      renderPanel();
    });
  }

  function togglePanel() {
    isOpen = !isOpen;
    if (isOpen && !panelOpenTracked) { panelOpenTracked = true; track('panel_open'); }
    if (panel) panel.classList.toggle('prbd-open', isOpen);
    fab.classList.toggle('prbd-fab-active', isOpen);
    // Load stages when panel first opens on a job page
    if (isOpen && !stagesLoaded && !isLoadingStages) loadStages();
  }

  // ══════════════════════════════════════════════════════
  // FAB
  // ══════════════════════════════════════════════════════

  const fab = document.createElement('button');
  fab.id = 'prbd-fab';
  fab.title = ADAPTER.title;
  fab.innerHTML = `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>`;
  fab.addEventListener('click', () => { if (!panel) createPanel(); togglePanel(); });
  document.body.appendChild(fab);
  createPanel();

})();
