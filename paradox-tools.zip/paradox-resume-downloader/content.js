(() => {
  'use strict';

  // ══════════════════════════════════════════════════════
  // STATE
  // ══════════════════════════════════════════════════════

  let panel = null;
  let isOpen = false;
  let activeTab = 'resumes'; // 'resumes' or 'disposition'

  // Shared
  let candidates = [];
  let selectedIds = new Set();
  let isScanning = false;
  let isLoadingStages = false;
  let stagesLoaded = false;
  // Each filter option: { label, stageIds: [], statusIds: [] }
  let scanFilterOptions = [];
  let selectedFilterIndex = 0; // index into scanFilterOptions, 0 = first option
  let scanLimit = 0; // 0 = all candidates
  let scanOffset = 0; // pagination offset for limited scans
  let totalAvailable = 0; // total candidates available from API

  // Resume state
  let isDownloading = false;
  let downloadProgress = { done: 0, total: 0, errors: [] };
  let downloadMode = 'folder';

  // Disposition state
  let isDisposing = false;
  let disposeProgress = { done: 0, total: 0, errors: [] };
  let journeyStages = [];
  let nextStepsData = null; // from check-journey-next-steps
  let selectedNextStepId = null; // the next_step button (e.g., "Disposition")
  let selectedStatusId = null; // the specific status within that next step

  // ══════════════════════════════════════════════════════
  // HELPERS
  // ══════════════════════════════════════════════════════

  function getCSRFToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    if (meta) return meta.getAttribute('content');
    const match = document.cookie.match(/csrftoken=([^;]+)/);
    return match ? match[1] : '';
  }

  function getSubdomain() { return window.location.hostname.split('.')[0]; }

  function apiHeaders() {
    return { 'accept': 'application/json, text/plain, */*', 'x-csrftoken': getCSRFToken(), 'x-requested-with': 'XMLHttpRequest' };
  }

  function getPageContext() {
    const p = new URL(window.location.href).searchParams;
    return { liveJobUuid: p.get('selected'), journeyId: p.get('journey') };
  }

  function candidateFilename(name) {
    return name.replace(/[^a-zA-Z0-9 _-]/g, '').replace(/\s+/g, '_') + '.pdf';
  }

  // ══════════════════════════════════════════════════════
  // PARALLEL + RETRY
  // ══════════════════════════════════════════════════════

  async function parallelBatch(items, asyncFn, concurrency = 5) {
    const results = new Array(items.length);
    let nextIndex = 0;
    async function worker() {
      while (nextIndex < items.length) { const i = nextIndex++; results[i] = await asyncFn(items[i], i); }
    }
    await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, () => worker()));
    return results;
  }

  async function withRetry(fn, { retries = 3, baseDelay = 500, label = '' } = {}) {
    for (let attempt = 1; attempt <= retries; attempt++) {
      try { return await fn(); } catch (err) {
        if (attempt === retries) throw err;
        await new Promise(r => setTimeout(r, baseDelay * Math.pow(2, attempt - 1)));
      }
    }
  }

  // ══════════════════════════════════════════════════════
  // API CALLS
  // ══════════════════════════════════════════════════════

  async function fetchAllCandidates(liveJobUuid, journeyId, stageIds = [], statusIds = [], maxCandidates = 0, startOffset = 0) {
    const subdomain = getSubdomain();
    const all = []; let offset = startOffset; const limit = 25; let total = Infinity;
    const stageFilter = stageIds.length > 0 ? JSON.stringify(stageIds) : '[]';
    const statusFilter = statusIds.length > 0 ? JSON.stringify(statusIds) : '[]';

    while (offset < total) {
      const url = `https://${subdomain}.paradox.ai/api/job-centric-view/get-candidates-by-stage?live_job_uuid=${liveJobUuid}&keyword=&stage_ids=${encodeURIComponent(stageFilter)}&status_ids=${encodeURIComponent(statusFilter)}&journey_id=${journeyId}&offset=${offset}&limit=${limit}&order_type=0&time_filter=4&is_previous=false`;
      let data, retries = 3;
      while (retries > 0) {
        try {
          const resp = await fetch(url, { credentials: 'include', headers: apiHeaders() });
          if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
          data = await resp.json(); break;
        } catch (err) {
          retries--;
          if (retries === 0) throw new Error(`Failed at offset ${offset}: ${err.message}`);
          await new Promise(r => setTimeout(r, 1500));
        }
      }
      total = data.total || 0;
      const batch = data.candidates || [];
      all.push(...batch); offset += limit;
      updateStatus(`Found ${all.length} of ${maxCandidates > 0 ? Math.min(total, maxCandidates) : total} candidates...`);
      if (batch.length === 0) break;
      // Stop if we've hit the limit
      if (maxCandidates > 0 && all.length >= maxCandidates) {
        all.length = maxCandidates; // trim to exact limit
        break;
      }
      if (offset < total) await new Promise(r => setTimeout(r, 300));
    }
    return { candidates: all, total };
  }

  async function fetchLeadData(candidateUuid) {
    const subdomain = getSubdomain();
    const url = `https://${subdomain}.paradox.ai/api/lead/${candidateUuid}?support_auto_translation=0&no_perm_raise=0&with_candidate_summary_data=1&with_integration_message=1`;
    const resp = await fetch(url, { credentials: 'include', headers: { ...apiHeaders(), 'referer': window.location.href, 'cache-control': 'no-cache' } });

    if (!resp.ok) {
      const cemResp = await fetch(`https://${subdomain}.paradox.ai/api/lead/cem-xhr`, {
        method: 'PUT', credentials: 'include',
        headers: { ...apiHeaders(), 'content-type': 'application/json', 'referer': window.location.href },
        body: JSON.stringify({ candidate_uuid: candidateUuid, latest_message_id: 0, unsubscribed: 0, is_live: 0, with_candidate_summary_data: 1, support_auto_translation: 0, page_type: '' })
      });
      if (!cemResp.ok) throw new Error(`Lead: ${resp.status}, cem-xhr: ${cemResp.status}`);
      return cemResp.json();
    }
    return resp.json();
  }

  async function fetchResumeUrl(docUuid) {
    const resp = await fetch(`https://${getSubdomain()}.paradox.ai/document/user/${docUuid.replace(/-/g, '')}?document_type=1`, { credentials: 'include', headers: apiHeaders() });
    if (!resp.ok) throw new Error(`Doc: ${resp.status}`);
    const d = await resp.json();
    if (d.success && d.document_url) return d.document_url;
    throw new Error('No doc URL');
  }

  async function fetchPdfBytes(candidate) {
    let url;
    if (candidate.fileUrl) url = candidate.fileUrl + (candidate.fileUrl.includes('?') ? '&' : '?') + 'is_download=true';
    else if (candidate.resumeUuid) url = await fetchResumeUrl(candidate.resumeUuid);
    const resp = await fetch(url, { credentials: 'include' });
    if (!resp.ok) throw new Error(`PDF: ${resp.status}`);
    return resp.arrayBuffer();
  }

  async function dispositionCandidate(uuid, stageId, statusId, nextStepId) {
    const body = { action: 'edit_candidate_journey_status', stage_id: stageId, status_id: statusId };
    if (nextStepId) { body.move_status_from_nextstep = true; body.next_step_id = nextStepId; }
    const resp = await fetch(`https://${getSubdomain()}.paradox.ai/api/lead/${uuid}`, {
      method: 'PUT', credentials: 'include',
      headers: { ...apiHeaders(), 'content-type': 'application/json', 'referer': window.location.href },
      body: JSON.stringify(body)
    });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const data = await resp.json();
    if (data.error && data.error.length > 0) throw new Error(data.error);
    return data;
  }

  async function fetchNextSteps(uuid, stageId, statusId) {
    const resp = await fetch(`https://${getSubdomain()}.paradox.ai/api/lead/${uuid}/check-journey-next-steps?stage_id=${stageId}&status_id=${statusId}&get_action_needed_statuses=0`, { credentials: 'include', headers: apiHeaders() });
    if (!resp.ok) return null;
    return resp.json();
  }

  // ══════════════════════════════════════════════════════
  // STAGE DISCOVERY
  // ══════════════════════════════════════════════════════

  async function loadStages() {
    const ctx = getPageContext();
    if (!ctx.liveJobUuid || !ctx.journeyId || stagesLoaded) return;

    isLoadingStages = true;
    renderPanel();

    try {
      const subdomain = getSubdomain();
      const probeUrl = `https://${subdomain}.paradox.ai/api/job-centric-view/get-candidates-by-stage?live_job_uuid=${ctx.liveJobUuid}&keyword=&stage_ids=[]&status_ids=[]&journey_id=${ctx.journeyId}&offset=0&limit=1&order_type=0&time_filter=4&is_previous=false`;
      const probeResp = await fetch(probeUrl, { credentials: 'include', headers: apiHeaders() });
      if (probeResp.ok) {
        const probeData = await probeResp.json();
        if (probeData.candidates?.length > 0) {
          const probeLead = await withRetry(() => fetchLeadData(probeData.candidates[0].uuid), { retries: 3, baseDelay: 800, label: 'probe' });
          if (probeLead.candidate_journey_statuses?.length > 0) {
            journeyStages = probeLead.candidate_journey_statuses;
            stagesLoaded = true;

            // Build filter options by finding matching stages/statuses
            const findStage = (name) => journeyStages.find(s => s.stage_name === name);
            const findStatus = (stageName, statusName) => {
              const stg = findStage(stageName);
              if (!stg) return null;
              const st = stg.statuses?.find(s => s.status_name === statusName);
              return st ? { stageId: stg.stage_id, statusId: st.status_id } : null;
            };

            scanFilterOptions = [];

            // Candidate Review (status within Candidate Review stage)
            const cr = findStatus('Candidate Review', 'Candidate Review');
            if (cr) scanFilterOptions.push({ label: 'Candidate Review', stageIds: [cr.stageId], statusIds: [cr.statusId] });

            // Meets Minimum Qualifications (status within Candidate Review stage)
            const mmq = findStatus('Candidate Review', 'Meets Minimum Qualifications');
            if (mmq) scanFilterOptions.push({ label: 'Meets Minimum Qualifications', stageIds: [mmq.stageId], statusIds: [mmq.statusId] });

            // Recruiter Screen (entire stage)
            const rs = findStage('Recruiter Interview');
            if (rs) scanFilterOptions.push({ label: 'Recruiter Screen', stageIds: [rs.stage_id], statusIds: [] });

            // Manager Screen (entire stage)
            const ms = findStage('Manager Interview');
            if (ms) scanFilterOptions.push({ label: 'Manager Screen', stageIds: [ms.stage_id], statusIds: [] });

            // Manager Panel (entire stage)
            const mp = findStage('Manager Panel Interview');
            if (mp) scanFilterOptions.push({ label: 'Manager Panel', stageIds: [mp.stage_id], statusIds: [] });

            // Default: Candidate Review for disposition, first option for resumes
            if (activeTab === 'disposition') {
              selectedFilterIndex = 0; // Candidate Review
            } else {
              selectedFilterIndex = 0;
            }
          }
        }
      }
    } catch (e) {
      console.warn('[Paradox Tools] Could not load stages:', e);
    }

    isLoadingStages = false;
    renderPanel();
  }

  // ══════════════════════════════════════════════════════
  // SCAN
  // ══════════════════════════════════════════════════════

  function updateStatus(msg) { const el = panel?.querySelector('#prbd-status'); if (el) el.textContent = msg; }

  async function scanForCandidates() {
    const ctx = getPageContext();
    if (!ctx.liveJobUuid || !ctx.journeyId) { alert('Navigate to a job Centric View first.'); return; }

    isScanning = true; candidates = []; selectedIds.clear();
    nextStepsData = null; selectedNextStepId = null; selectedStatusId = null;
    downloadProgress = { done: 0, total: 0, errors: [] };
    disposeProgress = { done: 0, total: 0, errors: [] };
    renderPanel();

    try {
      // Use the selected filter
      const filter = scanFilterOptions[selectedFilterIndex] || { label: 'All', stageIds: [], statusIds: [] };
      const limitLabel = scanLimit > 0 ? ` (max ${scanLimit})` : '';
      updateStatus(`Fetching ${filter.label} candidates${limitLabel}...`);

      const result = await fetchAllCandidates(ctx.liveJobUuid, ctx.journeyId, filter.stageIds, filter.statusIds, scanLimit, scanOffset);
      totalAvailable = result.total;
      const conc = result.candidates.length > 300 ? 3 : result.candidates.length > 100 ? 4 : 5;
      let count = 0;

      candidates = await parallelBatch(result.candidates, async (c) => {
        try {
          const ld = await withRetry(() => fetchLeadData(c.uuid), { retries: 3, baseDelay: 800, label: c.name });
          const lead = ld.lead || {};
          const att = lead.attachments || [];
          const resume = att.find(a => a.resume_id || a.file_name?.toLowerCase().endsWith('.pdf'));
          // Grab journey stages from first successful lead if we don't have them yet
          if (journeyStages.length === 0 && ld.candidate_journey_statuses?.length > 0) journeyStages = ld.candidate_journey_statuses;
          const cjs = lead.candidate_journey_status || c.candidate_journey_status || {};
          count++; updateStatus(`Checked ${count} of ${result.candidates.length}...`);

          return {
            uuid: c.uuid, name: c.name || `${c.first_name} ${c.last_name}`, email: c.email || '',
            hasResume: !!resume, resumeUuid: resume?.uuid || resume?.resume_uuid || null,
            fileUrl: resume?.file_url || null, fileName: resume?.file_name || null,
            jobName: c.candidate_profile_job_name || lead.candidate_job_applied || '',
            currentStageId: cjs.stage_id, currentStatusId: cjs.status_id,
            currentStageName: cjs.status_name || '', currentJourneyName: cjs.journey_name || ''
          };
        } catch (err) {
          count++; updateStatus(`Checked ${count} of ${result.candidates.length}...`);
          return {
            uuid: c.uuid, name: c.name || `${c.first_name} ${c.last_name}`, email: c.email || '',
            hasResume: false, resumeUuid: null, fileUrl: null, fileName: null,
            jobName: c.candidate_profile_job_name || '',
            currentStageId: null, currentStatusId: null, currentStageName: '', currentJourneyName: '',
            error: err.message
          };
        }
      }, conc);
    } catch (err) {
      console.error('[Paradox Tools] Scan failed:', err);
      alert(`Scan failed: ${err.message}`);
    }

    // Fetch next-steps from the first candidate that has a current stage/status
    const sampleCandidate = candidates.find(c => c.currentStageId && c.currentStatusId);
    console.log('[Paradox Tools] Sample candidate for next-steps:', sampleCandidate?.name, 'stageId:', sampleCandidate?.currentStageId, 'statusId:', sampleCandidate?.currentStatusId);
    if (sampleCandidate) {
      try {
        updateStatus('Loading disposition options...');
        const ns = await fetchNextSteps(sampleCandidate.uuid, sampleCandidate.currentStageId, sampleCandidate.currentStatusId);
        if (ns?.success && ns.next_steps) {
          nextStepsData = ns.next_steps;
          console.log('[Paradox Tools] Next steps loaded:', nextStepsData);
        }
      } catch (e) {
        console.warn('[Paradox Tools] Could not load next steps:', e);
      }
    }

    isScanning = false; renderPanel();
  }

  // ══════════════════════════════════════════════════════
  // RESUME DOWNLOAD
  // ══════════════════════════════════════════════════════

  function updateDlStatus(msg) { const el = panel?.querySelector('#prbd-dl-status'); if (el) el.textContent = msg; }

  async function downloadAsFolder(list) {
    const zip = new JSZip(); let n = 0;
    await parallelBatch(list, async (c) => {
      try {
        const bytes = await withRetry(() => fetchPdfBytes(c), { retries: 3, baseDelay: 500, label: c.name });
        zip.file(candidateFilename(c.name), bytes);
        n++; downloadProgress.done = n;
      } catch (err) { n++; downloadProgress.done = n; downloadProgress.errors.push(`${c.name}: ${err.message}`); }
      renderPanel();
    }, 5);
    updateDlStatus('Zipping...');
    const blob = await zip.generateAsync({ type: 'blob' }, m => updateDlStatus(`Zipping... ${Math.round(m.percent)}%`));
    triggerDownload(blob, `Resumes_${new Date().toISOString().slice(0, 10)}.zip`);
  }

  async function downloadAsMerged(list) {
    const { PDFDocument } = PDFLib;
    const merged = await PDFDocument.create();
    let fetched = 0, mergeN = 0;

    for (let i = 0; i < list.length; i += 20) {
      const chunk = list.slice(i, i + 20);
      updateDlStatus(`Batch ${Math.floor(i/20)+1}/${Math.ceil(list.length/20)}: fetching...`);
      const results = await parallelBatch(chunk, async (c) => {
        try {
          const bytes = await withRetry(() => fetchPdfBytes(c), { retries: 3, baseDelay: 500, label: c.name });
          fetched++; downloadProgress.done = fetched; renderPanel();
          return { name: c.name, bytes };
        } catch (err) {
          fetched++; downloadProgress.done = fetched;
          downloadProgress.errors.push(`${c.name}: ${err.message}`);
          renderPanel(); return { name: c.name, bytes: null };
        }
      }, 5);

      for (const r of results) {
        if (!r.bytes) continue;
        try {
          mergeN++; updateDlStatus(`Merging ${mergeN}: ${r.name}...`);
          const donor = await PDFDocument.load(r.bytes, { ignoreEncryption: true });
          (await merged.copyPages(donor, donor.getPageIndices())).forEach(p => merged.addPage(p));
        } catch (e) { downloadProgress.errors.push(`${r.name}: Invalid PDF`); }
      }
    }

    updateDlStatus(`Saving (${merged.getPageCount()} pages)...`);
    triggerDownload(new Blob([await merged.save()], { type: 'application/pdf' }),
      `All_Resumes_${new Date().toISOString().slice(0, 10)}.pdf`);
  }

  function triggerDownload(blob, name) {
    const u = URL.createObjectURL(blob);
    const a = Object.assign(document.createElement('a'), { href: u, download: name });
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(u), 10000);
  }

  async function downloadSelected() {
    const list = candidates.filter(c => selectedIds.has(c.uuid) && c.hasResume && (c.resumeUuid || c.fileUrl));
    if (!list.length) return;
    isDownloading = true; downloadProgress = { done: 0, total: list.length, errors: [] }; renderPanel();
    if (downloadMode === 'merged') await downloadAsMerged(list); else await downloadAsFolder(list);
    isDownloading = false; renderPanel();
  }

  // ══════════════════════════════════════════════════════
  // BULK DISPOSITION
  // ══════════════════════════════════════════════════════

  async function bulkDisposition() {
    if (!selectedNextStepId || !selectedStatusId) { alert('Select an action and status first.'); return; }
    const list = candidates.filter(c => selectedIds.has(c.uuid) && !c.error);
    if (!list.length) return;

    // Look up the step and resolve the stage_id for the selected status
    const step = nextStepsData.find(s => s.id === selectedNextStepId);
    if (!step) return;

    // Find which stage this status belongs to
    let targetStageId = step.stages?.[0]; // default to first stage
    for (const stg of journeyStages) {
      if (stg.statuses?.find(s => s.status_id === selectedStatusId)) {
        if (step.stages.includes(stg.stage_id)) {
          targetStageId = stg.stage_id;
          break;
        }
      }
    }

    const statusLabel = (() => {
      for (const stg of journeyStages) {
        const st = stg.statuses?.find(s => s.status_id === selectedStatusId);
        if (st) return st.status_name;
      }
      return `Status ${selectedStatusId}`;
    })();

    if (!confirm(`Move ${list.length} candidate${list.length > 1 ? 's' : ''} to:\n\n${step.button_label}: ${statusLabel}\n\nContinue?`)) return;

    isDisposing = true; disposeProgress = { done: 0, total: list.length, errors: [] }; renderPanel();

    const conc = list.length > 300 ? 3 : list.length > 100 ? 4 : 5;
    await parallelBatch(list, async (c) => {
      try {
        await withRetry(() => dispositionCandidate(c.uuid, targetStageId, selectedStatusId, step.id),
          { retries: 3, baseDelay: 800, label: c.name });
        disposeProgress.done++;
      } catch (err) { disposeProgress.done++; disposeProgress.errors.push(`${c.name}: ${err.message}`); }
      renderPanel();
    }, conc);

    isDisposing = false; renderPanel();
  }

  // ══════════════════════════════════════════════════════
  // UI
  // ══════════════════════════════════════════════════════

  function createPanel() {
    panel = document.createElement('div');
    panel.id = 'prbd-panel';
    document.body.appendChild(panel);
    renderPanel();
  }

  function renderPanel() {
    if (!panel) return;
    const withResume = candidates.filter(c => c.hasResume);
    const selectable = activeTab === 'resumes' ? withResume : candidates.filter(c => !c.error);
    const selCount = [...selectedIds].filter(id => selectable.find(c => c.uuid === id)).length;
    const ctx = getPageContext();
    const busy = isScanning || isDownloading || isDisposing;

    panel.innerHTML = `
      <div class="prbd-header">
        <div class="prbd-title">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
          </svg>
          Paradox Tools
        </div>
        <button class="prbd-close" id="prbd-close">&times;</button>
      </div>

      <div class="prbd-tabs">
        <button class="prbd-tab ${activeTab === 'resumes' ? 'prbd-tab-active' : ''}" data-tab="resumes" ${busy ? 'disabled' : ''}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
            <polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
          </svg>
          Resumes
        </button>
        <button class="prbd-tab ${activeTab === 'disposition' ? 'prbd-tab-active' : ''}" data-tab="disposition" ${busy ? 'disabled' : ''}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="9 11 12 14 22 4"/>
            <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
          </svg>
          Disposition
        </button>
      </div>

      <div class="prbd-body">
        ${isScanning ? `<div class="prbd-scanning"><div class="prbd-spinner"></div><p id="prbd-status">Starting scan...</p></div>` :
          candidates.length === 0 ? `<div class="prbd-empty"><p>${ctx.liveJobUuid && ctx.journeyId ? 'Click <strong>Scan Page</strong> to find candidates.' : 'Navigate to a job <strong>Centric View</strong> first.'}</p></div>` :
          `
            <div class="prbd-stats">
              ${activeTab === 'resumes'
                ? `<strong>${candidates.length}</strong> candidates &middot; <strong>${withResume.length}</strong> with resumes`
                : `<strong>${candidates.length}</strong> candidates`}
              ${scanLimit > 0 && totalAvailable > 0 ? ` <span class="prbd-hint">(${scanOffset + 1}&ndash;${Math.min(scanOffset + scanLimit, totalAvailable)} of ${totalAvailable})</span>` : ''}
            </div>
            ${scanLimit > 0 && totalAvailable > scanLimit ? `
              <div class="prbd-pagination">
                <button class="prbd-btn prbd-btn-page" id="prbd-prev" ${scanOffset === 0 || busy ? 'disabled' : ''}>&larr; Prev ${scanLimit}</button>
                <button class="prbd-btn prbd-btn-page" id="prbd-next" ${scanOffset + scanLimit >= totalAvailable || busy ? 'disabled' : ''}>Next ${Math.min(scanLimit, totalAvailable - scanOffset - scanLimit)} &rarr;</button>
              </div>
            ` : ''}
            <div class="prbd-select-all">
              <label><input type="checkbox" id="prbd-select-all" ${selCount === selectable.length && selectable.length > 0 ? 'checked' : ''}> Select all (${selectable.length})</label>
            </div>
            <div class="prbd-list">
              ${candidates.map(c => {
                const dis = activeTab === 'resumes' ? !c.hasResume : !!c.error;
                return `<div class="prbd-candidate ${dis ? 'prbd-no-resume' : ''}"><label>
                  <input type="checkbox" data-uuid="${c.uuid}" ${dis ? 'disabled' : ''} ${selectedIds.has(c.uuid) ? 'checked' : ''}>
                  <div class="prbd-candidate-info">
                    <span class="prbd-candidate-name">${c.name}</span>
                    ${activeTab === 'disposition' && c.currentStageName ? `<span class="prbd-candidate-job">${c.currentStageName}</span>` : ''}
                    ${activeTab === 'resumes' && !c.hasResume ? '<span class="prbd-no-resume-tag">No resume</span>' : ''}
                    ${activeTab === 'resumes' && c.fileName ? `<span class="prbd-file-tag">${c.fileName}</span>` : ''}
                    ${c.error ? '<span class="prbd-no-resume-tag">Error</span>' : ''}
                  </div>
                </label></div>`;
              }).join('')}
            </div>
          `}

        ${activeTab === 'resumes' && isDownloading ? `<div class="prbd-progress">
          <div class="prbd-progress-bar"><div class="prbd-progress-fill" style="width:${(downloadProgress.done/downloadProgress.total)*100}%"></div></div>
          <p>${downloadProgress.done} / ${downloadProgress.total}</p><p id="prbd-dl-status" class="prbd-hint"></p>
          ${downloadProgress.errors.length ? `<div class="prbd-errors">${downloadProgress.errors.map(e=>`<p class="prbd-error">${e}</p>`).join('')}</div>` : ''}
        </div>` : ''}
        ${activeTab === 'resumes' && !isDownloading && downloadProgress.done > 0 ? `<div class="prbd-done">&#10003; ${downloadProgress.done - downloadProgress.errors.length} of ${downloadProgress.total} downloaded${downloadProgress.errors.length ? `<br><span class="prbd-error">${downloadProgress.errors.length} failed</span>` : ''}</div>` : ''}

        ${activeTab === 'disposition' && isDisposing ? `<div class="prbd-progress">
          <div class="prbd-progress-bar"><div class="prbd-progress-fill" style="width:${(disposeProgress.done/disposeProgress.total)*100}%"></div></div>
          <p>${disposeProgress.done} / ${disposeProgress.total} dispositioned</p>
          ${disposeProgress.errors.length ? `<div class="prbd-errors">${disposeProgress.errors.map(e=>`<p class="prbd-error">${e}</p>`).join('')}</div>` : ''}
        </div>` : ''}
        ${activeTab === 'disposition' && !isDisposing && disposeProgress.done > 0 ? `<div class="prbd-done">&#10003; ${disposeProgress.done - disposeProgress.errors.length} of ${disposeProgress.total} moved${disposeProgress.errors.length ? `<br><span class="prbd-error">${disposeProgress.errors.length} failed</span>` : ''}</div>` : ''}
      </div>

      <div class="prbd-actions">
        ${activeTab === 'resumes' && !isScanning && withResume.length > 0 && !isDownloading ? `
          <div class="prbd-mode-toggle">
            <button class="prbd-mode-btn ${downloadMode === 'folder' ? 'prbd-mode-active' : ''}" data-mode="folder">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg> Zip File
            </button>
            <button class="prbd-mode-btn ${downloadMode === 'merged' ? 'prbd-mode-active' : ''}" data-mode="merged">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg> Merged PDF
            </button>
          </div>
          <div class="prbd-action-btns">
            <button class="prbd-btn prbd-btn-download" id="prbd-download" ${selCount === 0 ? 'disabled' : ''}>
              ${downloadMode === 'merged' ? 'Merge' : 'Download Zip'}${selCount > 0 ? ` (${selCount})` : ''}
            </button>
          </div>
        ` : ''}

        ${activeTab === 'disposition' && !isScanning && candidates.length > 0 && !isDisposing ? `
          <div class="prbd-disposition-form">
            ${nextStepsData && nextStepsData.length > 0 ? (() => {
              // Build flat list of all status options with their parent step info
              const allOptions = [];
              for (const step of nextStepsData) {
                if (step.disabled) continue;
                for (const sid of step.statuses) {
                  let statusLabel = 'Status ' + sid;
                  let stageId = step.stages?.[0];
                  for (const stg of journeyStages) {
                    const st = stg.statuses?.find(s => s.status_id === sid);
                    if (st) { statusLabel = st.status_name; if (step.stages.includes(stg.stage_id)) stageId = stg.stage_id; break; }
                  }
                  allOptions.push({ sid, statusLabel, stepId: step.id, stepLabel: step.button_label, stageId });
                }
              }
              // Group by step label for optgroups
              const groups = {};
              for (const o of allOptions) {
                if (!groups[o.stepLabel]) groups[o.stepLabel] = [];
                groups[o.stepLabel].push(o);
              }
              const groupKeys = Object.keys(groups);
              return '<div class="prbd-form-group"><label class="prbd-form-label">Disposition</label>' +
                '<select class="prbd-select" id="prbd-disp-select"><option value="">Select disposition...</option>' +
                groupKeys.map(g => {
                  const opts = groups[g].map(o =>
                    '<option value="' + o.stepId + ':' + o.sid + ':' + o.stageId + '"' +
                    (selectedNextStepId === o.stepId && selectedStatusId === o.sid ? ' selected' : '') +
                    '>' + o.statusLabel + '</option>'
                  ).join('');
                  return groupKeys.length > 1
                    ? '<optgroup label="' + g + '">' + opts + '</optgroup>'
                    : opts;
                }).join('') +
                '</select></div>';
            })() : `
              <p class="prbd-hint">No disposition options available for these candidates.</p>
            `}
          </div>
          <div class="prbd-action-btns">
            <button class="prbd-btn prbd-btn-dispose" id="prbd-dispose" ${selCount === 0 || !selectedNextStepId || !selectedStatusId ? 'disabled' : ''}>
              Disposition${selCount > 0 ? ` (${selCount})` : ''}
            </button>
          </div>
        ` : ''}

        ${stagesLoaded && !isScanning ? `
          <div class="prbd-scan-filters">
            <div class="prbd-form-group prbd-stage-picker">
              <label class="prbd-form-label">Candidates In</label>
              <select class="prbd-select" id="prbd-scan-stage-select">
                ${scanFilterOptions.map((f, i) =>
                  `<option value="${i}" ${selectedFilterIndex === i ? 'selected' : ''}>${f.label}</option>`
                ).join('')}
              </select>
            </div>
            <div class="prbd-form-group prbd-limit-picker">
              <label class="prbd-form-label">Limit</label>
              <select class="prbd-select" id="prbd-scan-limit">
                <option value="0" ${scanLimit === 0 ? 'selected' : ''}>All</option>
                <option value="25" ${scanLimit === 25 ? 'selected' : ''}>25</option>
                <option value="50" ${scanLimit === 50 ? 'selected' : ''}>50</option>
                <option value="100" ${scanLimit === 100 ? 'selected' : ''}>100</option>
                <option value="200" ${scanLimit === 200 ? 'selected' : ''}>200</option>
              </select>
            </div>
          </div>
        ` : ''}
        ${isLoadingStages ? '<p class="prbd-hint" style="padding:0 0 6px">Loading stages...</p>' : ''}
        <div class="prbd-action-btns prbd-scan-row">
          <button class="prbd-btn prbd-btn-scan" id="prbd-scan" ${busy || isLoadingStages || (!ctx.liveJobUuid || !ctx.journeyId) ? 'disabled' : ''}>
            ${isScanning ? 'Scanning...' : candidates.length > 0 ? 'Re-scan' : 'Scan Page'}
          </button>
        </div>
      </div>
    `;

    // ── Bind events ──
    panel.querySelector('#prbd-close')?.addEventListener('click', togglePanel);
    panel.querySelector('#prbd-scan')?.addEventListener('click', () => { scanOffset = 0; scanForCandidates(); });
    panel.querySelector('#prbd-download')?.addEventListener('click', downloadSelected);
    panel.querySelector('#prbd-dispose')?.addEventListener('click', bulkDisposition);

    panel.querySelector('#prbd-prev')?.addEventListener('click', () => {
      scanOffset = Math.max(0, scanOffset - scanLimit);
      scanForCandidates();
    });
    panel.querySelector('#prbd-next')?.addEventListener('click', () => {
      scanOffset += scanLimit;
      scanForCandidates();
    });

    panel.querySelectorAll('.prbd-tab').forEach(t => t.addEventListener('click', () => {
      activeTab = t.dataset.tab; selectedIds.clear(); candidates = [];
      downloadProgress = { done: 0, total: 0, errors: [] };
      disposeProgress = { done: 0, total: 0, errors: [] };
      selectedFilterIndex = 0;
      scanOffset = 0;
      renderPanel();
    }));

    panel.querySelectorAll('.prbd-mode-btn').forEach(b => b.addEventListener('click', () => { downloadMode = b.dataset.mode; renderPanel(); }));

    panel.querySelector('#prbd-select-all')?.addEventListener('change', (e) => {
      if (e.target.checked) selectable.forEach(c => selectedIds.add(c.uuid)); else selectedIds.clear();
      renderPanel();
    });

    panel.querySelectorAll('.prbd-candidate input[type="checkbox"]').forEach(cb => cb.addEventListener('change', (e) => {
      if (e.target.checked) selectedIds.add(e.target.dataset.uuid); else selectedIds.delete(e.target.dataset.uuid);
      renderPanel();
    }));

    panel.querySelector('#prbd-scan-stage-select')?.addEventListener('change', (e) => {
      selectedFilterIndex = parseInt(e.target.value);
      scanOffset = 0;
      renderPanel();
    });

    panel.querySelector('#prbd-scan-limit')?.addEventListener('change', (e) => {
      scanLimit = parseInt(e.target.value);
      scanOffset = 0;
      renderPanel();
    });

    panel.querySelector('#prbd-disp-select')?.addEventListener('change', (e) => {
      if (e.target.value) {
        const [stepId, statusId, stageId] = e.target.value.split(':').map(Number);
        selectedNextStepId = stepId;
        selectedStatusId = statusId;
      } else {
        selectedNextStepId = null;
        selectedStatusId = null;
      }
      renderPanel();
    });
  }

  function togglePanel() {
    isOpen = !isOpen;
    if (panel) panel.classList.toggle('prbd-open', isOpen);
    fab.classList.toggle('prbd-fab-active', isOpen);
    // Load stages when panel first opens on a job page
    if (isOpen && !stagesLoaded && !isLoadingStages) loadStages();
  }

  // ══════════════════════════════════════════════════════
  // FAB
  // ══════════════════════════════════════════════════════

  const fab = document.createElement('button');
  fab.id = 'prbd-fab';
  fab.title = 'Paradox Tools';
  fab.innerHTML = `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>`;
  fab.addEventListener('click', () => { if (!panel) createPanel(); togglePanel(); });
  document.body.appendChild(fab);
  createPanel();
})();
