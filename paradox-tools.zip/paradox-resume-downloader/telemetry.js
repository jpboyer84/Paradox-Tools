// Paradox ATS Bulk Tools - anonymous usage telemetry
// Loaded before content.js. Exposes window.prbdTrack(event, fields).
//
// What is sent: a random per-install UUID, the event name, the tab/opening
// type, download format, a count of candidates involved, error count,
// extension version, browser (chrome/edge) and the Paradox subdomain.
// Nothing about candidates, users, or resume content ever leaves the page.

(function () {
  'use strict';

  // Replace with the /exec URL from the "Paradox Tools Analytics" web app deployment.
  const ENDPOINT = 'https://script.google.com/macros/s/AKfycbxa4DAQIaR-3c39O4JCgZXKL-db35x1PzGISSLrf3gXa-yRbYh9heKeYcq7RkgTAHHB/exec';

  let uidPromise = null;

  function getUid() {
    if (uidPromise) return uidPromise;
    uidPromise = new Promise((resolve) => {
      try {
        chrome.storage.local.get('prbd_uid', (res) => {
          if (chrome.runtime.lastError) return resolve('unknown');
          if (res && res.prbd_uid) return resolve(res.prbd_uid);
          const id = (crypto.randomUUID && crypto.randomUUID()) ||
            ('u-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10));
          chrome.storage.local.set({ prbd_uid: id }, () => resolve(id));
        });
      } catch (e) {
        resolve('unknown');
      }
    });
    return uidPromise;
  }

  function browserName() {
    const ua = navigator.userAgent;
    if (/Edg\//.test(ua)) return 'edge';
    if (/Chrome\//.test(ua)) return 'chrome';
    return 'other';
  }

  function version() {
    try { return chrome.runtime.getManifest().version; } catch (e) { return ''; }
  }

  function subdomain() {
    try { return location.hostname.split('.')[0]; } catch (e) { return ''; }
  }

  // Fire-and-forget. Never throws, never blocks the caller.
  window.prbdTrack = function (event, fields) {
    if (!ENDPOINT || ENDPOINT.indexOf('REPLACE_WITH') === 0) return;
    getUid().then((uid) => {
      const payload = Object.assign({
        uid: uid,
        event: event,
        version: version(),
        browser: browserName(),
        subdomain: subdomain()
      }, fields || {});
      try {
        // no-cors: request is sent, response is opaque. Apps Script still
        // receives the body in e.postData.contents. No host permission needed.
        fetch(ENDPOINT, {
          method: 'POST',
          mode: 'no-cors',
          keepalive: true,
          headers: { 'Content-Type': 'text/plain' },
          body: JSON.stringify(payload)
        }).catch(() => {});
      } catch (e) { /* ignore */ }
    }).catch(() => {});
  };
})();
